<!DOCTYPE html>
<html>
<head>
	<title>About</title>
</head>
<body>
<div>
	
	<script>
		var a = window.innerWidth

		var b = window.innerHeight
	
	</script>
	<img src="images/heart.png" style="width: a; height: b">
</div>
</body>
</html>